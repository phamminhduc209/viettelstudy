### Expected Behavior

*Describe expected behavior*

### Actual Behavior

*Describe actual behavior*

### Steps to reproduce

1.
2.
3.

### Environment

- *hardware | device*
- *operating system | version*
- *browser | version*
- *JW Player version | url*

----------------------------------------------------------------------------------------

This template is provided as a guide to filing bugs and feature requests. Please replace 
all text *in italics* with details describing your issue. When submitting a feature request, 
"Steps to reproduce" can be substituted with a user story or list of acceptance criteria.
