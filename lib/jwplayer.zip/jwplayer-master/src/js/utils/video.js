const video = document.createElement('video');
export default video;
