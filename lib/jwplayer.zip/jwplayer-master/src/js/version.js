export const version = __BUILD_VERSION__;

