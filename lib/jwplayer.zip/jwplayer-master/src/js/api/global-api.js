import availableProviders from 'providers/providers-supported';
import registerProvider from 'providers/providers-register';

export default {
    availableProviders,
    registerProvider
};
