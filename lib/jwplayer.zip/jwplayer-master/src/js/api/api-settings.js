export default {
    debug: false // __DEBUG__
};
