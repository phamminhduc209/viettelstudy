
export const dvrSeekLimit = -25;
