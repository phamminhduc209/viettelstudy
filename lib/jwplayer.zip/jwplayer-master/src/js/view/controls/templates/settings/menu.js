export default () => {
    return (
        `<div class="jw-reset jw-settings-menu" role="menu" aria-expanded="false">` +
            `<div class="jw-reset jw-settings-topbar" role="menubar">` +
            `</div>` +
        `</div>`
    );
};
