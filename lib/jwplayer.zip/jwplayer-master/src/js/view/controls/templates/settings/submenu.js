export default () => {
    return (
        `<div class="jw-reset jw-settings-submenu" role="menu" aria-expanded="false">` +
        `</div>`
    );
};
